package com.iset.silkroad2.entities;


public enum Tags {
    Restorant,
    transports,
    general

}

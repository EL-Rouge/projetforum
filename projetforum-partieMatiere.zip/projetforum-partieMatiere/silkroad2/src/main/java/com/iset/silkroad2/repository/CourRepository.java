package com.iset.silkroad2.repository;

import com.iset.silkroad2.entities.Cour;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourRepository  extends JpaRepository<Cour,Long> {


}

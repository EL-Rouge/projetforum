package com.iset.silkroad2.repository;

import com.iset.silkroad2.entities.Matiere;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MatiereRepository extends JpaRepository<Matiere, Long> {

}

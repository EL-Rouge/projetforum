package com.iset.silkroad2.controller;

public class NotFoundException extends Throwable {
    public NotFoundException(String questionNotFound) {
    }
}

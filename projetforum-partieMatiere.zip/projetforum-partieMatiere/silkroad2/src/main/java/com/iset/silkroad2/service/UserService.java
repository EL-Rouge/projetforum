package com.iset.silkroad2.service;

import com.iset.silkroad2.entities.User;
import com.iset.silkroad2.web.dto.UserRegistrationDto;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
    User save(UserRegistrationDto registrationDto);


}

package com.iset.silkroad2.repository;

import com.iset.silkroad2.entities.Chapitre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChapitreRepository extends JpaRepository<Chapitre, Long> {


}
